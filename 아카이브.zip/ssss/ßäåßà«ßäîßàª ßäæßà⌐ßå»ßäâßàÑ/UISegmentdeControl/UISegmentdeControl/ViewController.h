//
//  ViewController.h
//  UISegmentdeControl
//
//  Created by SWUCOMPUTER on 2015. 9. 16..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *info;

@property (strong, nonatomic) IBOutlet UISegmentedControl *deskOS;
@property (strong, nonatomic) IBOutlet UISegmentedControl *smartOS;
@property (strong, nonatomic) IBOutlet UISegmentedControl *yesMaybeNo;
@property (strong, nonatomic) IBOutlet UISegmentedControl *beerCoffeeWine;

- (IBAction)changeSelection:(UISegmentedControl *)sender;

@end


//
//  ViewController.m
//  UISegmentdeControl
//
//  Created by SWUCOMPUTER on 2015. 9. 16..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize deskOS; @synthesize smartOS; @synthesize yesMaybeNo; @synthesize beerCoffeeWine; @synthesize info;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)changeSelection:(UISegmentedControl *)sender {
    if(sender == self.deskOS || sender == self.yesMaybeNo || sender == self.smartOS) {
        self.info.text = [sender titleForSegmentAtIndex: [sender selectedSegmentIndex]]; } else {
            NSArray *opts = [NSArray arrayWithObjects:@"Beer", @"Coffee", @"Wine", nil];
            self.info.text = [opts objectAtIndex: [sender selectedSegmentIndex]]; }
}
@end

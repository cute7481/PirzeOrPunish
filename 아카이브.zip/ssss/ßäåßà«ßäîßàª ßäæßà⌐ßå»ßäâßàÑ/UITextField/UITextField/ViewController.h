//
//  ViewController.h
//  UITextField
//
//  Created by SWUCOMPUTER on 2015. 9. 16..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UILabel *info;
@property (strong, nonatomic) IBOutlet UITextField *pHolder;
@property (strong, nonatomic) IBOutlet UITextField *dText;

@property (strong, nonatomic) IBOutlet UITextField *cButton1;
@property (strong, nonatomic) IBOutlet UITextField *cButton2;
@property (strong, nonatomic) IBOutlet UITextField *cButton3;
@property (strong, nonatomic) IBOutlet UITextField *cButton4;

- (BOOL) textFieldShouldReturn:(UITextField *)textField;

@end


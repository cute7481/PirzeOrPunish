//
//  ViewController.m
//  Layout
//
//  Created by SWUCOMPUTER on 2015. 9. 16..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize textFd;
@synthesize display;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonDisplay:(UIButton *)sender {
    self.display.text = textFd.text;
}

- (IBAction)segControlDisplay:(UISegmentedControl *)sender {
    self.display.text = [sender titleForSegmentAtIndex:[sender selectedSegmentIndex]];
}

- (IBAction)switchDisplay:(UISwitch *)sender {
    if(sender.isOn) {
        self.display.text = @"On";
    } else {
        self.display.text = @"Off";
    }
}
/*
- (IBAction)sliderDisplay:(UISlider *)sender {
   self.display.text = ;
}
*/
- (BOOL) textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    self.display.text = [NSString stringWithFormat:@"%@", textField.text];
    return YES;
}

@end
//
//  ViewController.h
//  Layout
//
//  Created by SWUCOMPUTER on 2015. 9. 16..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UILabel *display;
@property (strong, nonatomic) IBOutlet UITextField *textFd;

- (IBAction)buttonDisplay:(UIButton *)sender;
- (IBAction)segControlDisplay:(UISegmentedControl *)sender;
- (IBAction)switchDisplay:(UISwitch *)sender;
//- (IBAction)sliderDisplay:(UISlider *)sender;

- (BOOL) textFieldShouldReturn:(UITextField *)textField;

@end


//
//  ViewController.m
//  ButtonTest
//
//  Created by SWUCOMPUTER on 2015. 9. 16..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize info; @synthesize image; @synthesize system; @synthesize infoLight; @synthesize addContact;

- (IBAction)buttonPressed:(UIButton *)sender {
    if(sender == self.image) {
        self.info.text = @"Image Button"; }
    else if(sender == self.system) {
        self.info.text = @"System Button"; }
    else if(sender == self.infoLight) {
        self.info.text = @"Info Light Button"; }
    else if(sender == self.addContact) {
        self.info.text = @"Add Contact Button"; }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

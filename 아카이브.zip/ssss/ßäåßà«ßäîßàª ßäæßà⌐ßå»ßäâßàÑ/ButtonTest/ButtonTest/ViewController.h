//
//  ViewController.h
//  ButtonTest
//
//  Created by SWUCOMPUTER on 2015. 9. 16..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *info;
@property (strong, nonatomic) IBOutlet UIButton *image;
@property (strong, nonatomic) IBOutlet UIButton *infoLight;
@property (strong, nonatomic) IBOutlet UIButton *addContact;
@property (strong, nonatomic) IBOutlet UIButton *system;
- (IBAction)buttonPressed:(UIButton *)sender;

@end


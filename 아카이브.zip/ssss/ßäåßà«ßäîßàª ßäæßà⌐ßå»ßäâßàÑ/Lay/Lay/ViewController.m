//
//  ViewController.m
//  Lay
//
//  Created by SWUCOMPUTER on 2015. 9. 16..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize info;
@synthesize tex;
@synthesize stepper1;
@synthesize stepper2;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonDisplay {
    self.info.text = self.tex.text;
}

- (IBAction)segControlDisplay:(UISegmentedControl *)sender {
    self.info.text = [sender titleForSegmentAtIndex: [sender selectedSegmentIndex]];
}

- (IBAction)switchDisplay:(UISwitch *)sender {
    if (sender.isOn) {
        self.info.text = @"On";
    }
    else {
        self.info.text = @"Off";
    }
}

- (IBAction)sliderDisplay:(UISlider *)sender {
    self.info.text = [NSString stringWithFormat:@"%f", (float) sender.value];
}

- (IBAction)stepperDisplay:(UIStepper *)sender {
    self.info.text = [NSString stringWithFormat:@"%d%d", (int) stepper1.value, (int) stepper2.value];
}

- (BOOL) textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    self.info.text = [NSString stringWithFormat:@"%@",textField.text];
    return YES;
}

@end

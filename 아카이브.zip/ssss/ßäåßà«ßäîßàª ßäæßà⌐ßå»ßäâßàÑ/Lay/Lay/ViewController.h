//
//  ViewController.h
//  Lay
//
//  Created by SWUCOMPUTER on 2015. 9. 16..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UILabel *info;
@property (strong, nonatomic) IBOutlet UITextField *tex;
@property (strong, nonatomic) IBOutlet UIStepper *stepper1;
@property (strong, nonatomic) IBOutlet UIStepper *stepper2;

- (IBAction)buttonDisplay;
- (IBAction)segControlDisplay:(UISegmentedControl *)sender;
- (IBAction)switchDisplay:(UISwitch *)sender;
- (IBAction)sliderDisplay:(UISlider *)sender;
- (IBAction)stepperDisplay:(UIStepper *)sender;

- (BOOL) textFieldShouldReturn:(UITextField *)textField;

@end


//
//  ViewController2.h
//  Lay
//
//  Created by SWUCOMPUTER on 2015. 9. 18..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController2 : UIViewController

@end

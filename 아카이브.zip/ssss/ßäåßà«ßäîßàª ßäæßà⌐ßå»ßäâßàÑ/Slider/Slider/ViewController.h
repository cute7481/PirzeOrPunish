//
//  ViewController.h
//  Slider
//
//  Created by SWUCOMPUTER on 2015. 9. 16..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UISlider *red;
@property (strong, nonatomic) IBOutlet UISlider *green;
@property (strong, nonatomic) IBOutlet UISlider *blue;
- (IBAction)updateColor:(UISlider *)sender;

@end


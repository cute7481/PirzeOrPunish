//
//  MakeViewController.h
//  YoonApp
//
//  Created by SWUCOMPUTER on 2015. 10. 8..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MakeViewController : UIViewController <UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *prizeName;
@property (strong, nonatomic) IBOutlet UILabel *stepperNum;
@property (strong, nonatomic) IBOutlet UISegmentedControl *pChoice;
@property (strong, nonatomic) IBOutlet UIStepper *pStepper;
@property (strong, nonatomic) IBOutlet UIDatePicker *pDate;
@property (strong, nonatomic) IBOutlet UISwitch *onOffSwitch;

@property (strong, nonatomic) IBOutlet UITextField *pText;

- (IBAction)makeNum:(UIStepper *)sender;

- (BOOL) textFieldShouldReturn:(UITextField *)textField;

@end

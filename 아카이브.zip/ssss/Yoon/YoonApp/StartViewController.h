//
//  StartViewController.h
//  YoonApp
//
//  Created by SWUCOMPUTER on 2015. 10. 13..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StartViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource> {
    NSArray * data1;
    NSArray * data2;
}

@property (strong, nonatomic) IBOutlet UILabel *target;
@property (strong, nonatomic) IBOutlet UIPickerView *targetView;

- (IBAction)getValue:(UIButton *)sender;

@end

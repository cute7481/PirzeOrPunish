//
//  Coupon.h
//  YoonApp
//
//  Created by SWUCOMPUTER on 2015. 10. 12..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Coupon : NSObject

+ (Coupon *) initWithName:(NSString *)nameValue andChoice:(NSString *)choiceValue;

- (NSString *) name;
- (void) setName:(NSString *)nameValue;

- (NSString *) choice;
- (void) setChoice:(NSString *)choiceValue;

@end

//
//  PrizeTableViewController.h
//  YoonApp
//
//  Created by SWUCOMPUTER on 2015. 10. 13..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PrizeTableViewController : UITableViewController <UITableViewDataSource, UITableViewDelegate> {
    NSMutableArray *mutableArray;
}

@property (strong, nonatomic) IBOutlet UITableView *prizeTable;

@end

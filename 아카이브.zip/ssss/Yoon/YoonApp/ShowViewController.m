//
//  ShowViewController.m
//  YoonApp
//
//  Created by SWUCOMPUTER on 2015. 10. 11..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import "ShowViewController.h"
#import "Coupon.h"
#import "AppDelegate.h"

@interface ShowViewController ()

@end

@implementation ShowViewController

@synthesize segCho, choDue, choName;
@synthesize choS, choD, choN, onOffStatus;
@synthesize subView, message;

- (BOOL) textFieldShouldReturn: (UITextField *) textField {
    [message resignFirstResponder];
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    segCho.text = choS;
    choDue.text = choD;
    choName.text = choN;
    [subView setHidden:!onOffStatus];
    
    /*
    Coupon * a;
    a.name = choN;
    a.choice = choS;
    
    //[saving addObject:[Coupon initWithName:choN andChoice:choS]];
    

    //save = [[NSMutableArray alloc] init];
    //[save addObject:[Coupon initWithName:choN andChoice:choS]];
    //[[NSUserDefaults standardUserDefaults]setValue:choN forKey:choS];
     */
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

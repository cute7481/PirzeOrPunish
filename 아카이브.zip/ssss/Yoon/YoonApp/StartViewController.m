//
//  StartViewController.m
//  YoonApp
//
//  Created by SWUCOMPUTER on 2015. 10. 13..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import "StartViewController.h"

@interface StartViewController ()

@end

@implementation StartViewController

@synthesize target, targetView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    data1 = [[NSArray alloc] initWithObjects:@"상", @"벌", nil];
    data2 = [[NSArray alloc] initWithObjects:@"100개 받기", @"안받기", @"한번은 받기", @"꽉꽉 채우기", nil];
    //data2 = [[NSArray alloc] initWithObjects:@"100개 받기", @"안받기", @"한번쯤 받아보자", @"꽉꽉 채우기", nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)getValue:(UIButton *)sender {
    NSString* first = [data1 objectAtIndex:[self.targetView selectedRowInComponent: 0]];
    NSString* second = [data2 objectAtIndex:[self.targetView selectedRowInComponent: 1]];
    self.target.text = [first stringByAppendingFormat:@" %@", second];
}

- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 2;
}

- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (component == 0)
        return [data1 count];
    else
        return [data2 count];
}

- (NSString *) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (component == 0)
        return [data1 objectAtIndex:row];
    else
        return [data2 objectAtIndex:row];
}

@end

//
//  ShowViewController.h
//  YoonApp
//
//  Created by SWUCOMPUTER on 2015. 10. 11..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShowViewController : UIViewController <UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UILabel *segCho;
@property (strong, nonatomic) IBOutlet UILabel *choName;
@property (strong, nonatomic) IBOutlet UILabel *choDue;
@property (strong, nonatomic) IBOutlet UIView *subView;
@property (strong, nonatomic) IBOutlet UITextField *message;

@property (strong, nonatomic) NSString *choS;
@property (strong, nonatomic) NSString *choN;
@property (strong, nonatomic) NSString *choD;
@property (assign, nonatomic) BOOL onOffStatus;

- (BOOL) textFieldShouldReturn:(UITextField *)textField;

@end
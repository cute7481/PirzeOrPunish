//
//  MyTableViewCell.h
//  YoonApp
//
//  Created by SWUCOMPUTER on 2015. 10. 11..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTableViewCell : UITableViewCell

@end

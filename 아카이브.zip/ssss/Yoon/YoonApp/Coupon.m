//
//  Coupon.m
//  YoonApp
//
//  Created by SWUCOMPUTER on 2015. 10. 12..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import "Coupon.h"

@implementation Coupon{
    NSString * name;
    NSString * choice;
}

+ (Coupon *) initWithName:(NSString *)nameValue andChoice:(NSString *)choiceValue {
    Coupon * result = [[Coupon alloc] init];
    result.name = nameValue;
    result.choice = choiceValue;
    return result;
}

- (NSString *) name {
    return self->name;
}

- (void) setName:(NSString *)nameValue {
    if (nameValue != nil) self->name = nameValue;
}

- (NSString *) choice {
    return self->choice;
}

- (void) setChoice:(NSString *)choiceValue {
    if (choiceValue != nil) self->choice = choiceValue;
}

@end

//
//  MakeViewController.m
//  YoonApp
//
//  Created by SWUCOMPUTER on 2015. 10. 8..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import "MakeViewController.h"
#import "ShowViewController.h"

@interface MakeViewController ()

@end

@implementation MakeViewController

@synthesize stepperNum;
@synthesize prizeName, pChoice, pStepper, pDate, onOffSwitch, pText;

- (BOOL) textFieldShouldReturn: (UITextField *) textField {
    [pText resignFirstResponder];
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)makeNum:(UIStepper *)sender {
    stepperNum.text = [NSString stringWithFormat:@"%d", (int)pStepper.value];
}

- (void) prepareForSegue: (UIStoryboardSegue *) segue sender: (id) sender {
    ShowViewController *vc = [segue destinationViewController];
    NSString *selected = [pChoice titleForSegmentAtIndex:[pChoice selectedSegmentIndex]];
    vc.title = [selected stringByAppendingString:@"주기"];
    vc.choS = [NSString stringWithFormat:@"%@ # %d회권", selected, (int)pStepper.value];
    vc.choN = [NSString stringWithFormat:@"%@", prizeName.text];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeStyle: NSDateFormatterShortStyle];
    [dateFormatter setDateStyle: NSDateFormatterMediumStyle];
    vc.choD = [NSString stringWithFormat:@"유효기간 : %@", [dateFormatter stringFromDate: pDate.date]];
    if (onOffSwitch.isOn)
        vc.onOffStatus = true;
    else
        vc.onOffStatus = false;
}

@end

//
//  PrizeTableViewController.m
//  YoonApp
//
//  Created by SWUCOMPUTER on 2015. 10. 13..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import "PrizeTableViewController.h"
#import "Coupon.h"

@interface PrizeTableViewController ()

@end

@implementation PrizeTableViewController 

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    self.prizeTable.delegate = self;
    self.prizeTable.dataSource = self;
    
    mutableArray = [[NSMutableArray alloc ]init];
    [mutableArray addObject:[Coupon initWithName:@"방청소 안하기" andChoice:@"상"]];
    [mutableArray addObject:[Coupon initWithName:@"빨래 넘기기" andChoice:@"상"]];
    //[mutableArray addObject:[Coupon initWithName:@"소원 들어주기" andChoice:@"상"]];
    //[mutableArray addObject:[Coupon initWithName:@"치킨 얻어먹기" andChoice:@"상"]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    //NSLog(@"numberOfSectionsInTableView:tableView");
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [self->dic count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *myCellPrize = @"myCellPrize";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:myCellPrize forIndexPath:indexPath];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:myCellPrize];
    }
    
    //NSMutableArray *as = [[NSMutableArray alloc]init];
    //as = [self->dic objectForKey:@"ss"];
    
    cell.textLabel.text = [[self->mutableArray objectAtIndex:indexPath.row]name];
    //cell.detailTextLabel.text = [[self->mutableArray objectAtIndex:indexPath.row]choice];
    cell.detailTextLabel.text =
    
    return cell;
    
}

/*
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:; forIndexPath:indexPath];
    
    // Configure the cell...
    
    return cell;
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  MyTableViewCell.m
//  YoonApp
//
//  Created by SWUCOMPUTER on 2015. 10. 11..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import "MyTableViewCell.h"

@implementation MyTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

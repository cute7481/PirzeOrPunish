//
//  AppDelegate.h
//  SecondP
//
//  Created by SWUCOMPUTER on 2015. 10. 7..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


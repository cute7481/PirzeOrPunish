//
//  ViewController.m
//  SecondP
//
//  Created by SWUCOMPUTER on 2015. 10. 7..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import "ViewController.h"
#import "OrderViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize pizzaChicken;
- (void) prepareForSegue: (UIStoryboardSegue *) segue sender: (id) sender
{
    OrderViewController *vc = [segue destinationViewController];
    NSString *ordered = [pizzaChicken titleForSegmentAtIndex: [pizzaChicken selectedSegmentIndex]];
    vc.title = ordered;
    ordered = [ordered stringByAppendingString:@", 맞나요?"];
    // OrderViewController의 public 변수인 info의 setter 함수를 호출해 값 설정함
    vc.info = [NSString stringWithFormat:@"감사합니다!! \n 주문내역: %@", ordered]; }

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

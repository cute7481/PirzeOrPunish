//
//  ViewController.m
//  Navigation1to1
//
//  Created by CSE SWU on 2015. 7. 22..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import "ViewController.h"
#import "OrderViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize pizzaChicken;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) prepareForSegue: (UIStoryboardSegue *) segue sender: (id) sender
{
    OrderViewController *vc = [segue destinationViewController];
    
    NSString *ordered = [pizzaChicken   titleForSegmentAtIndex:
                           [pizzaChicken   selectedSegmentIndex]];
    vc.title = ordered;
    ordered = [ordered stringByAppendingString:@", 맞나요?"];
    
    // RentalViewController의 public 변수인 info의 setter 함수를 호출해 값 설정함
    vc.info = [NSString stringWithFormat:@"감사합니다!! \n 주문내역: %@", ordered];
}

@end

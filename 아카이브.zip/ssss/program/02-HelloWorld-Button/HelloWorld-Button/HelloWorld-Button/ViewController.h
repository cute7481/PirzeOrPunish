//
//  ViewController.h
//  HelloWorld-Button
//
//  Created by CSE SWU on 2015. 7. 3..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *labelHello;
@property (strong, nonatomic) IBOutlet UIButton *buttonWorld;
@property (strong, nonatomic) IBOutlet UIButton *buttonSWU;
@property (strong, nonatomic) IBOutlet UIButton *buttonMyName;

- (IBAction) buttonWorldPressed;
- (IBAction) buttonSWUPressed;
- (IBAction) buttonMyNamePressed;

@end


//
//  ViewController.h
//  SegControls
//
//  Created by CSE SWU on 2015. 7. 9..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *info;

@property (strong, nonatomic) IBOutlet UISegmentedControl *deskOS;
@property (strong, nonatomic) IBOutlet UISegmentedControl *smartOS;
@property (strong, nonatomic) IBOutlet UISegmentedControl *yesMaybeNo;
@property (strong, nonatomic) IBOutlet UISegmentedControl *beerCoffeeWine;

- (IBAction)changeSelection:(UISegmentedControl *)sender;

@end


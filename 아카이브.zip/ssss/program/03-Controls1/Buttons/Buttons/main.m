//
//  main.m
//  Buttons
//
//  Created by CSE SWU on 2015. 7. 8..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

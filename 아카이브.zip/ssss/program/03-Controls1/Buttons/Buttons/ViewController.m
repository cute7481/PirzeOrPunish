//
//  ViewController.m
//  Buttons
//
//  Created by CSE SWU on 2015. 7. 8..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize info;
@synthesize image;
@synthesize system;
@synthesize infoLight;
@synthesize addContact;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonPressed:(UIButton *)sender {
    if(sender == self.image) {
        self.info.text = @"Image Button";
    }
    else if(sender == self.system) {
        self.info.text = @"System Button";
    }
    else if(sender == self.infoLight) {
        self.info.text = @"Info Light Button";
    }
    else if(sender == self.addContact) {
        self.info.text = @"Add Contact Button";
    }
}

@end

//
//  ViewController.m
//  Slides
//
//  Created by CSE SWU on 2015. 7. 8..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize red;
@synthesize green;
@synthesize blue;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)updateColor:(UISlider *)sender {
    self.view.backgroundColor = [UIColor colorWithRed:self.red.value
                                                green:self.green.value
                                                 blue:self.blue.value
                                                alpha:1.0];
}
@end

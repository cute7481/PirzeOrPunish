//
//  ViewController.h
//  Switches
//
//  Created by CSE SWU on 2015. 7. 8..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *info;
@property (strong, nonatomic) IBOutlet UISwitch *switch1;
@property (strong, nonatomic) IBOutlet UISwitch *switch2;

- (IBAction)toggle:(UISwitch *)sender;

@end


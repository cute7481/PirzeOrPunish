//
//  ViewController.m
//  Switches
//
//  Created by CSE SWU on 2015. 7. 8..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize switch1;
@synthesize switch2;
@synthesize info;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)toggle:(UISwitch *)sender {
    if(sender == self.switch1) {
        self.info.text = @"Toggled by Switch 1";
        // switch1을 선택하면 switch2의 상태가 반전되도록 설정한다
        [self.switch2 setOn:!self.switch2.isOn animated:YES];
    }
    else {
        self.info.text = @"Toggled by Switch 2";
        // switch2를 선택하면 switch1의 상태가 반전되도록 설정한다
        [self.switch1 setOn:!self.switch1.isOn animated:YES];
    }
}
@end

//
//  ViewController.m
//  Views
//
//  Created by CSE SWU on 2015. 7. 19..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize red, green, blue, color;
@synthesize visible, subView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)updateColor {
    self.color.backgroundColor = [UIColor colorWithRed: red.value
                                                 green: green.value
                                                  blue: blue.value
                                                 alpha: 1.0];
}

- (IBAction)toggleView {
    [self.subView setHidden:!self.visible.isOn];
}

@end
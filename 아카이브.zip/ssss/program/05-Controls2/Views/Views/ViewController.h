//
//  ViewController.h
//  Views
//
//  Created by CSE SWU on 2015. 7. 19..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UISlider *red;
@property (strong, nonatomic) IBOutlet UISlider *green;
@property (strong, nonatomic) IBOutlet UISlider *blue;
@property (strong, nonatomic) IBOutlet UISwitch *visible;

@property (strong, nonatomic) IBOutlet UIView *color;
@property (strong, nonatomic) IBOutlet UIView *subView;

- (IBAction)updateColor;
- (IBAction)toggleView;

@end


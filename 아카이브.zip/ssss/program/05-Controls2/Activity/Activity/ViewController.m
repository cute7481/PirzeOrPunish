//
//  ViewController.m
//  Activity
//
//  Created by CSE SWU on 2015. 7. 14..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize activity1;
@synthesize activity2;
@synthesize activity3;
@synthesize start;
@synthesize stop;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)update:(UIButton *)sender {
    if(self.start == sender) {
        [self.activity1 startAnimating];
        [self.activity2 startAnimating];
        [self.activity3 startAnimating];
    } else
        if(self.stop == sender) {
            [self.activity1 stopAnimating];
            [self.activity2 stopAnimating];
            [self.activity3 stopAnimating];
        }
}
@end

//
//  AppDelegate.h
//  Activity
//
//  Created by CSE SWU on 2015. 7. 14..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


//
//  ViewController.m
//  ImageView
//
//  Created by CSE SWU on 2015. 7. 15..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize candleImageView, candleStateLabel, onOffSwitch;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [super viewDidLoad];
    candleOffImage = [UIImage imageNamed:@"candle-off.jpg"];
    candleOnImage  = [UIImage imageNamed:@"candle-on.jpg"];
    [candleImageView setImage:candleOnImage]; //default
    candleStateLabel.text = @"Candle is On.";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)toggleCandle {
    if (self.onOffSwitch.isOn) {
        [candleImageView setImage:candleOnImage];
        candleStateLabel.text = @"Candle is now On!";
    }
    else {
        [candleImageView setImage:candleOffImage];
        candleStateLabel.text = @"Candle is Off!";
    }
}
@end

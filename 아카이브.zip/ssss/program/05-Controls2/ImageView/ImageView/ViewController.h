//
//  ViewController.h
//  ImageView
//
//  Created by CSE SWU on 2015. 7. 15..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    UIImage *candleOffImage;
    UIImage *candleOnImage;
}

@property (strong, nonatomic) IBOutlet UIImageView *candleImageView;
@property (strong, nonatomic) IBOutlet UILabel *candleStateLabel;
@property (strong, nonatomic) IBOutlet UISwitch *onOffSwitch;

- (IBAction)toggleCandle;

@end


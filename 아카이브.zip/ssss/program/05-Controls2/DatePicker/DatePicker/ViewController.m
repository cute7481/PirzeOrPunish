//
//  ViewController.m
//  DatePicker
//
//  Created by CSE SWU on 2015. 7. 13..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize picker;
@synthesize info;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)getDateTime {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeStyle: NSDateFormatterShortStyle];
    [dateFormatter setDateStyle: NSDateFormatterMediumStyle];
    self.info.text = [dateFormatter stringFromDate: self.picker.date];
}

@end

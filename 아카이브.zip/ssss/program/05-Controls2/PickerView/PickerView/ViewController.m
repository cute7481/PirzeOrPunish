//
//  ViewController.m
//  PickerView
//
//  Created by CSE SWU on 2015. 7. 13..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize info;
@synthesize picker;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    data1 = [[NSArray alloc] initWithObjects:@"1학년", @"2학년",
             @"3학년", @"4학년", nil];
    data2 = [[NSArray alloc] initWithObjects:@"컴퓨터학과", @"정보보호학과",
            @"멀티미디어학과", @"컨텐츠디자인학과", nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 2;
}
- (NSInteger) pickerView:(UIPickerView *)pickerView
        numberOfRowsInComponent:(NSInteger)component {
    if (component == 0)
        return [data1 count];
    else
        return [data2 count];
}

- (NSString *) pickerView:(UIPickerView *)pickerView
              titleForRow:(NSInteger)row  forComponent:(NSInteger)component {
    if (component == 0)
        return [data1 objectAtIndex:row];
    else
        return [data2 objectAtIndex:row];
}
- (IBAction)getValue {
    NSString* first = [data1 objectAtIndex:[self.picker selectedRowInComponent:0]];
    NSString* second = [data2 objectAtIndex:[self.picker selectedRowInComponent:1]];
    
    self.info.text = [first stringByAppendingFormat:@" %@", second];
}

@end

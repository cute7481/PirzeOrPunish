//
//  ViewController.h
//  Objective-C
//
//  Created by CSE SWU on 2015. 7. 12..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)compare;
- (IBAction)nsString;
- (IBAction)nsMutableString;
- (IBAction)nsArray;
- (IBAction)nsMutableArray;
- (IBAction)nsDictionary;
- (IBAction)nsMutableDictionary;
- (IBAction)nsSet;
- (IBAction)nsMutableSet;
- (IBAction)enumeration;
- (IBAction)nsNumber;
- (IBAction)nsDate;

@end


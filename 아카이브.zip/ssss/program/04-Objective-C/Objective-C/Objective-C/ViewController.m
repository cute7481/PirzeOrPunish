//
//  ViewController.m
//  Objective-C
//
//  Created by CSE SWU on 2015. 7. 12..
//  Copyright (c) 2015년 CSE SWU. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)compare {
    NSString *one, *two, *three;
    one = @"Test";
    two = @"Test";
    three = two;
    
    if (one == two) NSLog(@"one and two are ==");
    if (one == three) NSLog(@"one and three are ==");
    if (two == three) NSLog(@"two and three are ==");
    NSLog(@"\n");
    
    NSArray *a1 = [NSArray arrayWithObject:@"One"];
    NSArray *a2 = [NSArray arrayWithObject:@"One"];
    NSArray *a3 = a2;
    
    if (a1 == a2) NSLog(@"a1 and a2 are ==");
    if (a1 == a3) NSLog(@"a1 and a3 are ==");
    
    if (a2 == a3) NSLog(@"a2 and a3 are ==");
    NSLog(@"\n");
    
    if ( [a1 isEqual:a2] ) NSLog(@"a1 and a2 are isEqual");
    if ( [a1 isEqual:a3] ) NSLog(@"a1 and a3 are isEqual");
    if ( [a2 isEqual:a3] ) NSLog(@"a2 and a3 are isEqual");
    NSLog(@"\n");
}

- (IBAction)nsString {
    NSString *who = @"Kang";
    NSString *teach = [NSString stringWithFormat:@"%@ is teaching", who];
    NSLog(@"01. %@\n", teach);
    
    NSString *msg = [NSString stringWithFormat:@"pi is: %.2f", 3.14159265];
    NSLog(@"02. %@\n", msg);
    
    msg = [who stringByAppendingString:@" is teaching"];
    NSLog(@"03. %@\n", msg);
    
    msg = [msg stringByAppendingFormat:@" at %02d:%02d pm", 2, 0];
    NSLog(@"04. %@\n", msg);
    
    NSString *haahoohee = @"haa hoo hee";
    NSString *haa = [haahoohee substringToIndex: 3];
    NSString *hoo = [haahoohee substringWithRange: NSMakeRange(4, 3)];
    NSString *hee = [haahoohee substringFromIndex: 8];
    NSLog(@"05. ---%@---%@---%@---\n", haa, hoo, hee);
    
    if ([@"haa" isEqualToString:@"haa"]) NSLog(@"06. String Equal\n");
    
    if ([@"haa" caseInsensitiveCompare:@"HAA"] == NSOrderedSame) NSLog(@"07. case insensitive OK\n");
    
    NSString * address = @"Seoul, Nowon-Gu";
    if ([address hasPrefix:@"Seo"]) NSLog(@"08. Prefix OK\n");
    
    if ([address hasSuffix:@"Gu"]) NSLog(@"09. Suffix OK\n");
    
    NSLog(@"10. Length of address: %d\n", [address length]);
    
    NSString *lower = [haahoohee lowercaseString];
    NSString *upper = [haahoohee uppercaseString];
    NSString *capitalized = [haahoohee capitalizedString];
    NSLog(@"11. ---%@---%@---%@---", lower, upper, capitalized);
}

- (IBAction)nsMutableString {
    NSMutableString *haa = [NSMutableString stringWithString:@"haa"];
    [haa appendString:@" hoo"];
    NSLog(@"%@\n", haa);
    
    [haa appendFormat:@", pi = %.2f", 3.14159265];
    NSLog(@"%@\n", haa);
    
    [haa insertString:@" hee" atIndex:7];
    NSLog(@"%@\n", haa);
    
    [haa deleteCharactersInRange: NSMakeRange(1, 4)];
    NSLog(@"%@\n", haa);
}

- (IBAction)nsArray {
    NSArray *array = [NSArray arrayWithObjects:@"Computer", @"Security",
                      @"Multimedia", @"Content", nil];
    NSLog(@"array = %@\n", array);
    NSLog(@"count = %d\n", [array count]);
    
    if ([array containsObject:@"Computer"])
        NSLog(@"Yes!! Computer contains in the array!!\n");
    else
        NSLog(@"No!! No Computer is in the array!!\n");
    
    int index = [array indexOfObject:@"Computer"];
    if (index == NSNotFound)
        NSLog(@"Index Not found!\n");
    else
        NSLog(@"Index Found!!  Index is %d\n", index);
    
    index = 1;
    NSString *item = [array objectAtIndex:index];
    NSLog(@"Array[%d] = %@\n", index, item);
}

- (IBAction)nsMutableArray {
    NSMutableArray *array = [NSMutableArray arrayWithObjects:@"Computer", @"Security", nil];
    NSLog(@"1. array = %@\n", array);
    
    [array addObject:@"Multimedia"];
    NSLog(@"2. array = %@\n", array);
    
    [array removeObject:@"Security"];
    NSLog(@"3. array = %@\n", array);
    
    [array insertObject:@"Info-Security" atIndex:1];
    NSLog(@"4. array = %@\n", array);
    
    [array removeObject:@"Info-Security"];
    NSLog(@"5. array = %@\n", array);
    
    [array removeAllObjects];
    NSLog(@"6. array = %@\n", array);
}

- (IBAction)nsDictionary {
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:
                          @"Operating System", @"11111", @"Computer Networks", @"22222", nil];
    NSLog(@"%@\n", dict); //[dict description]);
    NSLog(@"Number of Items = %d", [dict count]);
    
    NSLog(@"%@\n", [dict objectForKey:@"11111"]);
    NSLog(@"%@\n", [dict objectForKey:@"Operating"]);
}

- (IBAction)nsMutableDictionary {
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                 @"Operating System", @"11111", @"Computer Networks", @"22222", nil];
    NSLog(@"%@\n", [dict description]);
    
    [dict setObject:@"System Programming" forKey:@"33333"];
    NSLog(@"%@\n", [dict description]);
    
    [dict removeObjectForKey:@"22222"];
    NSLog(@"%@\n", [dict description]);
    
    [dict removeAllObjects];
    NSLog(@"%@\n", [dict description]);
}

- (IBAction)nsSet {
    NSSet *colors = [NSSet setWithObjects:@"Red", @"Green", @"Blue", nil];
    NSLog(@"%@\n", [colors description]);
    NSLog(@"Number of Elements = %d\n", [colors count]);
    
    if ([colors containsObject:@"Red"])
        NSLog(@"Set Contains Red\n");
    else
        NSLog(@"Set does NOT Contain Red\n");
}

- (IBAction)nsMutableSet {
    NSMutableSet *colors = [NSMutableSet setWithObjects:
                            @"Red", @"Green", @"Blue", nil];
    NSLog(@"%@\n", [colors description]);
    NSLog(@"Number of Elements = %d\n", [colors count]);
    
    [colors addObject: @"Yellow"];
    NSLog(@"addObject --> %@\n", [colors description]);
    
    [colors removeObject:@"Blue"];
    NSLog(@"removeObject --> %@\n", [colors description]);
    
    [colors removeAllObjects];
    NSLog(@"removeAllObject ==> %@\n", [colors description]);
    
    NSMutableSet *screen = [NSMutableSet setWithObjects: @"Red", @"Green", @"Blue", nil];
    NSMutableSet *paint = [NSMutableSet setWithObjects:
                           @"Red", @"Yellow", @"Blue", nil];
    [screen unionSet: paint];
    NSLog(@"unionSet --> %@\n", [screen description]);
    
    screen = [NSMutableSet setWithObjects: @"Red", @"Green", @"Blue", nil];
    [screen intersectSet: paint];
    NSLog(@"intersectSet --> %@\n", [screen description]);
    
    screen = [NSMutableSet setWithObjects: @"Red", @"Green", @"Blue", nil];
    NSMutableSet *cold = [NSMutableSet setWithObjects: @"Green", @"Blue", nil];
    [screen minusSet: cold];
    NSLog(@"minusSet --> %@\n", [screen description]);
}

- (IBAction)enumeration {
    NSArray *collection = [NSArray arrayWithObjects:@"Computer", @"Security",
                           @"Multimedia", @"Content", nil];
    NSLog(@"%@\n", [collection description]);
    
    for(int i = 0, n = [collection count]; i < n; i++) {
        NSString *str = [collection objectAtIndex: i ];
        NSLog(@"%@ uppercased is %@", str, [str uppercaseString]);
    }
    NSLog(@"\n");
    
    for(NSString *str in collection) {
        NSLog(@"%@ lowercased is %@", str, [str lowercaseString]);
    }
}

- (IBAction)nsNumber {
    NSNumber *anInt = [NSNumber numberWithInt: 5];
    NSNumber *aDouble = [NSNumber numberWithDouble: 3.14];
    NSLog(@"Integer:%@   Real:%@\n", anInt, aDouble);
    
    int inum = [anInt intValue];
    double dnum = [aDouble floatValue];
    NSLog(@"int:%d   double:%.3f\n", inum, dnum);
    
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:
                          anInt, @"Five", aDouble, @"Pi", nil];
    NSLog(@"%@\n", [dict description]);
}

- (IBAction)nsDate {
    NSDate *then = [NSDate date];
    sleep(3);
    NSDate *now = [NSDate date];
    NSLog(@"<<Past Time>> %@\n", [then description]);
    NSLog(@"was 3 seconds away from\n");
    NSLog(@"<<Current Time>> %@\n", [now description]);
}

@end

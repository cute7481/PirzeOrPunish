//
//  CandleViewController.h
//  Week06
//
//  Created by SWUCOMPUTER on 2015. 10. 7..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CandleViewController : UIViewController{
    UIImage *candleOffImage;
    UIImage *candleOnImage;
}

@property (strong, nonatomic) IBOutlet UIImageView *candleImageView;
@property (strong, nonatomic) IBOutlet UILabel *candleStateLabel;

@property (assign, nonatomic) BOOL onOffStatus;

@end

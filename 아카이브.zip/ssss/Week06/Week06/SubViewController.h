//
//  SubViewController.h
//  Week06
//
//  Created by SWUCOMPUTER on 2015. 10. 7..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubViewController : UIViewController

@property (strong, nonatomic) IBOutlet UISlider *red;
@property (strong, nonatomic) IBOutlet UISlider *green;
@property (strong, nonatomic) IBOutlet UISlider *blue;

@property (strong, nonatomic) IBOutlet UIView *color;
@property (strong, nonatomic) IBOutlet UIView *subView;

@property (assign, nonatomic) BOOL onOffStatus;

- (IBAction)updateColor:(UISlider *)sender;



@end

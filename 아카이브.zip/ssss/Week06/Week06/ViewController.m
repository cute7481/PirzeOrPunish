//
//  ViewController.m
//  Week06
//
//  Created by SWUCOMPUTER on 2015. 10. 7..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import "ViewController.h"
#import "CandleViewController.h"
#import "SubViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize onOffSwitch;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) prepareForSegue: (UIStoryboardSegue *) segue sender: (id) sender {
    UIButton *button = (UIButton *) sender;
    if ([segue.identifier isEqualToString:@"toCandleView"]) {
        CandleViewController *vc = segue.destinationViewController;
        vc.title = button.titleLabel.text;
        if (onOffSwitch.isOn) {
            vc.onOffStatus = true;
        }
        else
            vc.onOffStatus = false;
    }
    else {
        SubViewController *vc = segue.destinationViewController;
        vc.title = button.titleLabel.text;
        if (onOffSwitch.isOn) {
            vc.onOffStatus = true;
        }
        else
            vc.onOffStatus = false;
    }
}

@end

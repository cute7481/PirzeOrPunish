//
//  MainViewController.h
//  Table
//
//  Created by Lim SungGil on 11. 11. 2..
//  Copyright 2011 actus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TableController.h"

@interface MainViewController : UIViewController {
    UIView				*mContentView;
    UIImageView         *mTopBG;
    TableController     *mTableView;
}

@end

//
//  TableAppDelegate.h
//  Table
//
//  Created by Lim SungGil on 11. 11. 2..
//  Copyright 2011 actus. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"

@interface TableAppDelegate : NSObject <UIApplicationDelegate> {
    MainViewController			* mViewController;
   	UIWindow					* mWindow;
}

@end

//
//  TableController.h
//  Table
//
//  Created by Lim SungGil on 11. 11. 2..
//  Copyright 2011 actus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableController : UITableViewController {
    UIView                  *mContentView;
    UITableView				*mTableView;
    NSMutableArray          *mData;
}

@end

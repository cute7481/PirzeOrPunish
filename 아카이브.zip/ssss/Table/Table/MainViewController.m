//
//  MainViewController.m
//  Table
//
//  Created by Lim SungGil on 11. 11. 2..
//  Copyright 2011 actus. All rights reserved.
//

#import "MainViewController.h"

@implementation MainViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    mContentView = [[[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]] retain];
    mContentView.backgroundColor = [UIColor whiteColor];
    self.view = mContentView;
    [mContentView release];
    
    mTableView = [[[TableController alloc] init] retain];
    [mContentView addSubview:mTableView.view];
    [mTableView release];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end

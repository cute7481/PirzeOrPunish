//
//  ViewController.m
//  Week07
//
//  Created by SWUCOMPUTER on 2015. 10. 14..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize resultR;
@synthesize firstTF, secondTF, indexTF;
@synthesize startB, clearB;
@synthesize picker, capS;

- (BOOL) textFieldShouldReturn: (UITextField *) textField {
    [textField resignFirstResponder];
    //self.info.text = [NSString stringWithFormat:@"%@", textField.text];
    return YES; }

- (IBAction)actionGo:(UIButton *)sender {
    NSInteger inx = [indexTF.text integerValue];
    NSString *fir = [data objectAtIndex:[self.picker selectedRowInComponent: 0]];
    if ([fir isEqualToString:@"Append"]) {
        resultR.text = [firstTF.text stringByAppendingString:secondTF.text];
    }
    else if ([fir isEqualToString:@"Insert"]) {
        NSMutableString *set = [NSMutableString stringWithString:firstTF.text];
        [set insertString:secondTF.text atIndex:inx];
        resultR.text = set;
    }
    else if([fir isEqualToString:@"SubFrom"]) {
        resultR.text = [firstTF.text substringFromIndex:inx];
    }
    else {
        resultR.text = [firstTF.text substringToIndex:inx];
    }
    if (self.capS.isOn) {
        resultR.text = [resultR.text uppercaseString];
    }
    else {
        resultR.text = [resultR.text lowercaseString];
    }

}

- (IBAction)actionClear:(UIButton *)sender {
    resultR.text = nil;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    data = [[NSArray alloc] initWithObjects:@"Append", @"Insert", @"SubFrom", @"SubTo", nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [data count];
}

- (NSString *) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return [data objectAtIndex:row];
}

@end

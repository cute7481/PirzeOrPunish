//
//  ViewController.h
//  Week07
//
//  Created by SWUCOMPUTER on 2015. 10. 14..
//  Copyright (c) 2015년 SWUCOMPUTER. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITextFieldDelegate,
UIPickerViewDelegate, UIPickerViewDataSource> {
    NSArray *data;
}

@property (strong, nonatomic) IBOutlet UILabel *resultR;

@property (strong, nonatomic) IBOutlet UITextField *firstTF;
@property (strong, nonatomic) IBOutlet UITextField *secondTF;
@property (strong, nonatomic) IBOutlet UITextField *indexTF;

@property (strong, nonatomic) IBOutlet UIButton *startB;
@property (strong, nonatomic) IBOutlet UIButton *clearB;

@property (strong, nonatomic) IBOutlet UIPickerView *picker;
@property (strong, nonatomic) IBOutlet UISwitch *capS;


- (IBAction)actionGo:(UIButton *)sender;
- (IBAction)actionClear:(UIButton *)sender;


- (BOOL) textFieldShouldReturn:(UITextField *)textField;

@end

